-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 15. Okt 2024 um 23:31
-- Server-Version: 10.4.27-MariaDB
-- PHP-Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `flexidrive`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `booking`
--

CREATE TABLE `booking` (
  `bookingId` int(11) UNSIGNED NOT NULL,
  `userId` int(11) UNSIGNED NOT NULL,
  `carId` int(11) UNSIGNED NOT NULL,
  `paymentId` int(11) UNSIGNED NOT NULL,
  `von` date NOT NULL,
  `bis` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `booking`
--

INSERT INTO `booking` (`bookingId`, `userId`, `carId`, `paymentId`, `von`, `bis`) VALUES
(1, 1, 5, 1, '2024-10-17', '2024-10-19');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `car`
--

CREATE TABLE `car` (
  `carId` int(11) UNSIGNED NOT NULL,
  `typeId` int(11) UNSIGNED NOT NULL,
  `locationId` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `preis` float NOT NULL,
  `bild` varchar(50) NOT NULL,
  `personen` int(11) NOT NULL,
  `tueren` varchar(50) NOT NULL,
  `getriebe` varchar(50) NOT NULL,
  `kraftstoff` varchar(50) NOT NULL,
  `verbrauch` float NOT NULL,
  `kw` int(11) NOT NULL,
  `ps` int(11) NOT NULL,
  `km` int(11) NOT NULL,
  `klimaanlage` tinyint(1) NOT NULL,
  `koffer` int(11) NOT NULL,
  `mindestalter` int(11) NOT NULL,
  `fuehrerschein` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `car`
--

INSERT INTO `car` (`carId`, `typeId`, `locationId`, `name`, `preis`, `bild`, `personen`, `tueren`, `getriebe`, `kraftstoff`, `verbrauch`, `kw`, `ps`, `km`, `klimaanlage`, `koffer`, `mindestalter`, `fuehrerschein`) VALUES
(5, 1, 1, 'VW Golf 8', 48.92, 'vw-golf.png', 5, '4/5', 'Automatikgetriebe', 'Benzin', 6.3, 221, 300, 21455, 1, 2, 18, 'Klasse B');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `location`
--

CREATE TABLE `location` (
  `locationId` int(11) UNSIGNED NOT NULL,
  `strasse` varchar(50) NOT NULL,
  `hausnummer` int(11) NOT NULL,
  `ort` varchar(50) NOT NULL,
  `postleitzahl` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `location`
--

INSERT INTO `location` (`locationId`, `strasse`, `hausnummer`, `ort`, `postleitzahl`) VALUES
(1, 'Karlsruher Strasse', 22, 'Pforzheim', 75179);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `payment`
--

CREATE TABLE `payment` (
  `paymentId` int(11) UNSIGNED NOT NULL,
  `strasse` varchar(50) NOT NULL,
  `hausnummer` int(11) NOT NULL,
  `ort` varchar(50) NOT NULL,
  `postleitzahl` int(5) NOT NULL,
  `kartennummer` int(50) NOT NULL,
  `kartenname` varchar(50) NOT NULL,
  `exp` varchar(50) NOT NULL,
  `cvv` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `payment`
--

INSERT INTO `payment` (`paymentId`, `strasse`, `hausnummer`, `ort`, `postleitzahl`, `kartennummer`, `kartenname`, `exp`, `cvv`) VALUES
(1, 'Wurmbergerstrasse', 38, 'Pforzheim', 75175, 123456789, 'Sparkasse PF/CW', '26', 59);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `type`
--

CREATE TABLE `type` (
  `typeId` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `type`
--

INSERT INTO `type` (`typeId`, `name`) VALUES
(1, 'pkw'),
(2, 'transporter'),
(3, 'wohnmobil'),
(4, 'sportwagen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `userId` int(11) UNSIGNED NOT NULL,
  `vorname` varchar(50) NOT NULL,
  `nachname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `passwort` varchar(100) NOT NULL,
  `rolle` varchar(20) NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`userId`, `vorname`, `nachname`, `email`, `passwort`, `rolle`) VALUES
(1, 'Colin', 'Djerdak', 'c.djerdak@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'customer'),
(2, 'Mirco', 'Djerdak', 'djerdakmirco@web.de', '0c53fd41f412543bbb0e2a383d7bd4b7', 'customer');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingId`),
  ADD KEY `userId` (`userId`),
  ADD KEY `cardId` (`carId`),
  ADD KEY `paymentId` (`paymentId`);

--
-- Indizes für die Tabelle `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`carId`),
  ADD KEY `typeId` (`typeId`),
  ADD KEY `locationId` (`locationId`);

--
-- Indizes für die Tabelle `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`locationId`);

--
-- Indizes für die Tabelle `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentId`);

--
-- Indizes für die Tabelle `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`typeId`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `car`
--
ALTER TABLE `car`
  MODIFY `carId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `location`
--
ALTER TABLE `location`
  MODIFY `locationId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `type`
--
ALTER TABLE `type`
  MODIFY `typeId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `userId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `cardId` FOREIGN KEY (`carId`) REFERENCES `car` (`carId`) ON DELETE CASCADE,
  ADD CONSTRAINT `paymentId` FOREIGN KEY (`paymentId`) REFERENCES `payment` (`paymentId`) ON DELETE CASCADE,
  ADD CONSTRAINT `userId` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `car`
--
ALTER TABLE `car`
  ADD CONSTRAINT `locationId` FOREIGN KEY (`locationId`) REFERENCES `location` (`locationId`) ON DELETE CASCADE,
  ADD CONSTRAINT `typeId` FOREIGN KEY (`typeId`) REFERENCES `type` (`typeId`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
