<section class="container py-5">
    <h1>Impressum</h1>
    <h4 class="text-secondary mb-5">Angaben gemäß §5 TMG</h4>

    <h5>Vertreten durch:</h5>
    <p class="mb-4">Colin Djerdak</p>

    <h5>Kontakt:</h5>
    <p class="mb-1">Telefon: +49 (0) 1631508578</p>
    <p class="mb-4 lh-1">Email: c.djerdak@web.de</p>

    <h5>Haftung für Inhalte und Links:</h5>
    <p class="mb-4">Der Seitenbetreiber ist verantwortlich für seinen eigenen Inhalt, jedoch nicht für Inhalt von Drittanbietern.<br>Externe Links wurden bei Einbinden geprüft, jedoch kann sich der Inhalt ändern, wofür der Seitenbetreiber nicht verantwortlich ist.</p>
    
    <h5>Copyright:</h5>
    <p>Inhalte, welche vom Seitenbetreiber erstellt wurden, sind gebunden an die deutsche Copyright-Verordnung. Jeglich Nutzung abseits des privaten oder nicht-kommerziellen Gebrauchs benötigt eine schriftliche Erlaubnis.</p>
</section>