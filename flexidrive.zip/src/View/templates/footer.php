        </main>

        <footer class="footer bg-primary-subtle">
            <p class="mb-0 py-2 text-center text-secondary"><small><a href="<?= ROUTE_BASE ?>/imprint">Impressum</a> / <a href="<?= ROUTE_BASE ?>/aboutUs">Über uns</a> / <a href="<?= ROUTE_BASE ?>/faq">FAQ</a><br>© <?= date("Y") ?> - Alle Rechte vorbehalten</small></p>
        </footer>

        <script src="assets/js/bootstrap.bundle.js"></script>
        <script src="assets/js/aos.js"></script>
        <script> AOS.init(); </script>
    </body>
</html>