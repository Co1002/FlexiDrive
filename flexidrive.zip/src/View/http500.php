<section class="container py-5">
    <h1 class="display-2">500</h1>
    <h2>Datenbank Fehler</h2>
    <p>Leider gab es ein Problem bei der Verbindung mit unserer Datenbank.<br>Bitte versuchen Sie es zu einem späteren Zeitpunkt erneut.</p>
    <p><a href="<?= ROUTE_BASE ?>/" class="btn btn-primary">Startseite</a><a href="javascript:history. back();" class="btn btn-outline-primary ms-2">Zurück</a></p>
</section>