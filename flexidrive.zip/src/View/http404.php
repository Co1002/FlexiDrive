<section class="container py-5">
    <h1 class="display-2">404</h1>
    <h2>Not found</h2>
    <p>Leider konnten wir die angeforderte Seite nicht finden.<br>Bitte überprüfen Sie ihre URL oder kehren zur Startseite zurück.</p>
    <p><a href="<?= ROUTE_BASE ?>/" class="btn btn-primary">Startseite</a><a href="javascript:history. back();" class="btn btn-outline-primary ms-2">Zurück</a></p>
</section>